const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const {
  createPost,
  getUserPosts,
  getCalendarPosts,
  approvePost,
  getPendingPosts,
  publishToSocialMedia
} = require('../controllers/postController');

// Existing routes
router.post('/', protect, createPost);
router.get('/', protect, getUserPosts);
router.get('/calendar', protect, getCalendarPosts);

// New routes
router.get('/pending', protect, getPendingPosts); // Admins fetch pending posts
router.post('/:id/approve', protect, approvePost); // Admin approves a post
router.post('/:id/publish', protect, publishToSocialMedia); // Editor/Admin publishes post

module.exports = router;
