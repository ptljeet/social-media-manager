const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verify token, attach user, and populate organization name
const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else {
    return res.status(401).json({ message: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Load user and populate organization name (only the name field)
    const user = await User.findById(decoded.id)
      .select('-password')
      .populate('organization', 'name');

    if (!user) return res.status(401).json({ message: 'User not found' });

    // Attach to req and normalize fields
    req.user = user;
    req.user.organization = user.organization?._id || decoded.organization || null;
    req.user.organizationName = user.organization?.name || null;

    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

// Allow Admin or Super Admin (case-insensitive)
const isAdmin = (req, res, next) => {
  const role = (req.user?.role || '').toLowerCase();
  if (role === 'admin' || role === 'super_admin') return next();
  return res.status(403).json({ message: 'Admin access required' });
};

module.exports = { protect, isAdmin };
// protect (unchanged if you already applied this)
const user = await User.findById(decoded.id)
  .select('-password')
  .populate('organization', 'name');

req.user = user;
req.user.organization = user.organization?._id || decoded.organization || null;
req.user.organizationName = user.organization?.name || null;
