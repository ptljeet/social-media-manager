const Post = require('../models/Post');
const User = require('../models/User');

// Create new post
exports.createPost = async (req, res) => {
  try {
    const newPost = new Post({ ...req.body, createdBy: req.user.id, status: 'draft' });
    await newPost.save();
    res.status(201).json(newPost);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create post' });
  }
};

// Get all posts (Admin) or by Org/Team
exports.getAllPosts = async (req, res) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { organization: req.user.organization };
    const posts = await Post.find(filter).populate('createdBy', 'name email');
    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
};

// Get post by ID
exports.getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('createdBy', 'name');
    if (!post) return res.status(404).json({ error: 'Post not found' });
    res.status(200).json(post);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching post' });
  }
};

// Approve a pending post
exports.approvePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    post.status = 'approved';
    await post.save();
    res.status(200).json({ message: 'Post approved successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error approving post' });
  }
};

// Get all pending posts (for Admin approval)
exports.getPendingPosts = async (req, res) => {
  try {
    const posts = await Post.find({ status: 'pending' }).populate('createdBy', 'name email');
    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching pending posts' });
  }
};

// Stub: Publish to FB/IG APIs
exports.publishToSocialMedia = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    // TODO: Replace with real API logic
    const platform = post.platform || 'facebook';
    console.log(`Publishing to ${platform}: ${post.content}`);

    post.status = 'published';
    post.publishedAt = new Date();
    await post.save();

    res.status(200).json({ message: 'Post published to social media (stub)' });
  } catch (error) {
    res.status(500).json({ error: 'Publishing failed' });
  }
};
